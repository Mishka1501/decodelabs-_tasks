"""
DecodeLabs Industrial Training Kit — Project 1
Data Cleaning & Preparation

Pipeline:
 1. Load raw dataset
 2. Audit: nulls, duplicates, formats
 3. Strategic Imputation (Median / Mode)
 4. Integrity Audit (dedupe on Order_ID)
 5. Standardise formats (dates ISO-8601, text proper-case, numerics 2dp, cities)
 6. Verification Gate: 0% duplicate IDs, 0% bad dates
 7. Export cleaned dataset + change log
"""
import pandas as pd, numpy as np, re, os, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW  = ROOT / "data" / "raw_orders.csv"
OUT  = ROOT / "data" / "cleaned_orders.csv"
LOG  = ROOT / "reports" / "change_log.json"

CITY_MAP = {
    "bangalore":"Bengaluru","bengaluru":"Bengaluru",
    "bombay":"Mumbai","mumbai":"Mumbai",
    "pondicherry":"Puducherry","puducherry":"Puducherry",
}

def to_iso_date(v):
    if pd.isna(v) or str(v).strip()=="": return pd.NaT
    for fmt in ("%Y-%m-%d","%d/%m/%Y","%m-%d-%Y","%d-%b-%Y"):
        try: return pd.to_datetime(v, format=fmt).date()
        except Exception: pass
    try: return pd.to_datetime(v, dayfirst=True, errors="coerce").date()
    except Exception: return pd.NaT

def to_price(v):
    if pd.isna(v): return np.nan
    s=str(v).replace(",","").replace("$","").strip()
    try: return round(float(s),2)
    except: return np.nan

def main():
    df = pd.read_csv(RAW)
    original_rows = len(df)
    changes = []

    # Drop fully blank rows
    blanks = int(df.isna().all(axis=1).sum())
    df = df.dropna(how="all")
    changes.append({"id":"CR001","description":"Removed fully blank rows","impact":f"{blanks} rows dropped","status":"Resolved"})

    # Trim/normalise text
    for c in ["Customer_Name","Email","City","Product","Status"]:
        df[c] = df[c].astype(str).str.strip()

    df["Customer_Name"] = df["Customer_Name"].str.title()
    df["Email"] = df["Email"].str.lower()
    df["Status"] = df["Status"].str.title().replace({"":np.nan})
    changes.append({"id":"CR002","description":"Trimmed whitespace, applied Proper Case to names, lower-cased emails, title-cased status","impact":"Text standardised across 5 fields","status":"Resolved"})

    # City standardisation
    df["City"] = df["City"].str.lower().map(CITY_MAP).fillna(df["City"].str.title())
    changes.append({"id":"CR003","description":"Standardised city names via canonical map","impact":"Bangalore→Bengaluru, Bombay→Mumbai, Pondicherry→Puducherry","status":"Resolved"})

    # Numeric coercion
    df["Unit_Price"] = df["Unit_Price"].apply(to_price)
    df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce")
    df.loc[df["Quantity"]<=0, "Quantity"] = np.nan
    df["Age"] = pd.to_numeric(df["Age"], errors="coerce")
    df.loc[(df["Age"]<0)|(df["Age"]>110), "Age"] = np.nan
    changes.append({"id":"CR004","description":"Coerced numerics; invalid Quantity/Age set to NaN for imputation","impact":"Removed negative & out-of-range values","status":"Resolved"})

    # Strategic Imputation
    age_median = df["Age"].median()
    price_median = df["Unit_Price"].median()
    qty_mode = df["Quantity"].mode().iloc[0]
    status_mode = df["Status"].mode().iloc[0]
    n_age = df["Age"].isna().sum()
    n_price = df["Unit_Price"].isna().sum()
    n_qty = df["Quantity"].isna().sum()
    n_status = df["Status"].isna().sum()
    df["Age"] = df["Age"].fillna(age_median)
    df["Unit_Price"] = df["Unit_Price"].fillna(price_median).round(2)
    df["Quantity"] = df["Quantity"].fillna(qty_mode).astype(int)
    df["Status"] = df["Status"].fillna(status_mode)
    changes.append({"id":"CR005","description":f"Imputed Age (median={age_median}), Unit_Price (median={price_median}), Quantity (mode={qty_mode}), Status (mode={status_mode})","impact":f"Preserved {n_age+n_price+n_qty+n_status} records vs listwise deletion","status":"Resolved"})

    # Date normalisation → ISO 8601
    df["Order_Date"] = df["Order_Date"].apply(to_iso_date)
    bad_dates = df["Order_Date"].isna().sum()
    df = df.dropna(subset=["Order_Date"])
    changes.append({"id":"CR006","description":"Parsed mixed date formats to ISO-8601 (YYYY-MM-DD); dropped unparseable dates","impact":f"{bad_dates} unparseable dates removed","status":"Resolved"})

    # Integrity Audit: dedupe on Order_ID
    dupes = df.duplicated(subset=["Order_ID"]).sum()
    df = df.drop_duplicates(subset=["Order_ID"], keep="first")
    changes.append({"id":"CR007","description":"Deduplicated on Order_ID (unique primary key)","impact":f"{dupes} duplicate transactions eliminated","status":"Resolved"})

    # Derived
    df["Order_Value"] = (df["Quantity"] * df["Unit_Price"]).round(2)

    # Verification Gate
    assert df["Order_ID"].is_unique, "GATE FAIL: duplicate Order_IDs"
    assert df["Order_Date"].notna().all(), "GATE FAIL: bad dates"
    gate = {"duplicate_id_rate":0.0, "bad_date_rate":0.0, "final_rows":len(df), "original_rows":original_rows}

    OUT.parent.mkdir(parents=True, exist_ok=True)
    LOG.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT, index=False)
    with open(LOG,"w") as f:
        json.dump({"gate":gate,"changes":changes}, f, indent=2)

    print(f"[OK] {original_rows} → {len(df)} rows | gate PASSED")
    for c in changes: print(" -", c["id"], c["description"])

if __name__ == "__main__":
    main()
