# Project 1 — Data Cleaning & Preparation
**DecodeLabs Industrial Training Kit · Batch 2026**

## Goal
Transform a raw, messy orders dataset into a production-ready "Gold Standard"
source of truth by handling missing values, duplicates, and inconsistent formats.

## Structure
```
DataCleaning_Project1/
├── data/
│   ├── raw_orders.csv         # Original messy dataset (216 rows)
│   └── cleaned_orders.csv     # Verified output (185 rows)
├── scripts/
│   └── clean_data.py          # Reproducible cleaning pipeline
├── notebooks/
│   └── data_cleaning.ipynb    # Step-by-step walkthrough
├── reports/
│   ├── change_log.json        # Machine-readable audit trail
│   └── change_log.pdf         # Stakeholder PDF change log
└── README.md
```

## How to Run
```bash
pip install pandas numpy reportlab
python scripts/clean_data.py
```

## Pipeline Phases
1. **Strategic Imputation** — median for Age & Unit_Price, mode for Quantity & Status.
2. **Integrity Audit** — deduplicated on `Order_ID` (primary key).
3. **Format Standardisation** — ISO-8601 dates, Proper Case names, canonical city map, 2-dp numerics.

## Verification Gate  ✅
- 0% duplicate `Order_ID`
- 0% invalid `Order_Date`
- 216 → 185 clean rows

## Author
Submitted for **DecodeLabs · Data Analytics Internship — Project 1**.
