# Project 2 — Exploratory Data Analysis
### Telco Customer Churn | Forensic EDA Case File
**DecodeLabs Industrial Training Kit — Batch 2026**

---

## 🎯 Problem Statement
A telecom provider is losing customers at an unknown rate. Leadership needs to know **who is churning, why, and where retention spend should go**.

## 🧪 Methodology (IPO Framework)
1. **Input** — 1,500-row customer dataset (tenure, charges, income, contract, support activity, churn label).
2. **Process** — missing-value audit → five-number summaries → outlier detection (IQR + Z-score) → Pearson correlation → segmentation.
3. **Output** — the findings & recommendations in `reports/Executive_Summary.pdf`.

## 📁 Folder Structure
```
EDA_Project2_CustomerChurn/
├── README.md                 ← you are here
├── requirements.txt          ← Python dependencies
├── data/
│   └── telco_customer_churn.csv
├── notebooks/
│   └── EDA_Analysis.ipynb    ← step-by-step notebook
├── src/
│   └── eda_analysis.py       ← end-to-end reproducible script
├── plots/                    ← generated visualizations (6 PNGs)
└── reports/
    ├── Executive_Summary.pdf ← stakeholder-facing deliverable
    ├── descriptive_stats.csv
    └── eda_summary.txt
```

## ▶️ How to Run
```bash
pip install -r requirements.txt
python src/eda_analysis.py         # regenerates data, plots, and PDF
jupyter notebook notebooks/EDA_Analysis.ipynb
```

## 🔑 Key Findings
| Signal | Evidence | Business Meaning |
|---|---|---|
| Contract type is #1 churn driver | Month-to-month = **37% churn** vs Two-year = **1.9%** | Convert MTM customers to annual plans |
| Low tenure = high risk | Churners cluster in first 12 months | Fund a 90-day onboarding program |
| Support-call volume flags churn | Median calls doubles for churners | Auto-route 4+ callers to retention |
| Income is right-skewed | Skew = 11.2 | Segment on medians, not means |

## 💡 Recommendations
1. Launch incentivized migration from month-to-month → annual contracts.
2. Build a 90-day new-customer loyalty program.
3. Trigger retention workflow at 4+ support calls / 30 days.
4. Rebuild marketing segments on income medians and deciles.

## 🛡️ Portfolio Checklist (per brief, slide 21)
- [x] Narrative structure — Problem → Insight
- [x] Clean, modular code
- [x] Data forensics — missing values & outliers handled
- [x] Business impact — quantified findings
- [x] Clear README for non-technical readers

> *"You are the translator between data and decision."* — DecodeLabs
